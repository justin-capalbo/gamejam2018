﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAudioController : MonoBehaviour {

    public AudioClip jump;
    public AudioClip transmitting;
    public AudioClip transmissionSent;

}
